﻿using SimpleTracer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace SimpleTracer
{
    /// <summary>
    /// 管理程序配置
    /// </summary>
    public sealed class AppConfigManager
    {
          
        /// <summary>
        /// 私有构造函数，阻止外界创建实例
        /// </summary>
        private AppConfigManager() { }



        private const string fileName = "config.json";

        private static AppConfigManager manager = new AppConfigManager();

        private  bool isLoaded = false;

        /// <summary>
        /// 返回管理器的唯一实例
        /// </summary>
        /// <returns></returns>
        public static AppConfigManager GetManager()
        {
            if (!manager.isLoaded)
            {
                manager.Load(); 
            }
            return manager;
        }

        /// <summary>
        /// 获取配置对象
        /// </summary>
        public AppConfig Config { get; private set; }

        public void Load()
        {
            try
            {
                if (!File.Exists(fileName))
                {
                    Logger.Log("找不到配置文件，尝试创建新文件。");
                    Config = new AppConfig();
                    Save();
                    isLoaded = true;
                }
                else
                {
                    var json = File.ReadAllText(fileName);
                    Config = JsonConvert.DeserializeObject<AppConfig>(json);
                    isLoaded = true;
                    Logger.Log("加载配置成功");
                }
                
            }
            catch (Exception e)
            {
                Logger.Log("加载配置发生错误：\n" + e);
            }
        }

        /// <summary>
        /// 保存配置
        /// </summary>
        public void Save()
        {
            try
            {
                if (Config != null)
                {
                    File.WriteAllText(fileName, JsonConvert.SerializeObject(Config));
                    Logger.Log("保存配置成功");
                }
            }
            catch (Exception e)
            {
                Logger.Log("保存配置发生错误：\n" + e);
            }
        }
    }
}

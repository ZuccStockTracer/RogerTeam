﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Diagnostics;

namespace SimpleTracer
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //SystemParameters.StaticPropertyChanged += SystemParameters_StaticPropertyChanged;
        }

        public ObservableCollection<UserControl> AppControls { get; }
            = new ObservableCollection<UserControl>();

        //private void SystemParameters_StaticPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        //{
        //    if (e.PropertyName == "WindowGlassBrush")
        //    {
        //    }
        //}

        private void panelList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var current = e.AddedItems[0] as ListBoxItem;
            if (current?.Tag is Type type)
            {
                try
                {
                    var controls = from ctl in AppControls 
                                   where ctl.GetType() == type
                                   select ctl;
                    //如果已经存在指定类型的元素
                    if (controls.Count() > 0)
                        mainContent.Child = controls.First();
                    else
                    {
                        //通过反射创建类型
                        if (Activator.CreateInstance(type) is UserControl newControl)
                        {
                            AppControls.Add(newControl);
                            Logger.Log($"创建UserControl '{type.Name}' 成功");
                            mainContent.Child = newControl;
                            
                        }

                    }
                }
                catch (Exception ex)
                {
                    Logger.Log($"创建新控件 '{type.Name}' 失败\r\n{ex}");
                }

            }
            menu.IsChecked = false;
        }
    }


    
}

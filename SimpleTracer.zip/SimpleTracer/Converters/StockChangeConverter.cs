﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using static Microsoft.VisualBasic.Information;
using static Microsoft.VisualBasic.Conversion;
using System.Windows.Media;

namespace SimpleTracer.Converters
{
    /// <summary>
    /// 股票涨跌值的XAML值转换器
    /// </summary>
    class StockChangeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (IsNumeric(value))
            {
                var v = Val(value);
                //转换涨跌值到颜色
                if (targetType == typeof(Brush) || targetType.IsSubclassOf(typeof(Brush)))
                {
                    return v > 0 ? Brushes.Red
                        : v < 0 ? Brushes.LimeGreen
                        : Brushes.Black;
                }
                //格式化涨跌值
                else if (targetType == typeof(string))
                {
                    return (v > 0 ? ("+" + value) : value ) +
                        (parameter?.ToString() == "%" ? "%" : "");
                }
            } 
            throw new InvalidCastException($"无法执行从 '{value.GetType().FullName}' 到 '{targetType.FullName}' 的转换。");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

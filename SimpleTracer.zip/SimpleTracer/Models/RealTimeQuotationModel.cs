﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleTracer.Models
{
    /// <summary>
    /// 实时行情API返回的Model类
    /// </summary>
    public class RealTimeQuotationModel
    {
        /// <summary>
        /// 股票代码
        /// </summary>
        public string prod_code { get; set; }
        /// <summary>
        /// 详细数据快照
        /// </summary>
        public snapshot_detail_data snapshot { get; set; }

    }

#pragma warning disable CS1591

    /// <summary>
    /// 实时行情API返回的详细数据Model
    /// </summary>
    public class snapshot_detail_data
    {
        
        public string prod_name { get; set; }

        public int data_timestamp { get; set; }

        public double open_px { get; set; }

        public double high_px { get; set; }

        public double low_px { get; set; }

        public double last_px { get; set; }

        public double preclose_px { get; set; }

        public long business_amount { get; set; }

        public double business_balance { get; set; }

        public int shares_per_hand { get; set; }

        public long business_amount_in { get; set; }

        public long business_amount_out { get; set; }

        public double up_px { get; set; }

        public double down_px { get; set; }

        public double amplitude { get; set; }

        public long circulation_value { get; set; }

        public double eps { get; set; }

        public double pe_rate { get; set; }

        public double px_change { get; set; }

        public double px_change_rate { get; set; }

        public double dyn_pb_rate { get; set; }

        public double turnover_ratio { get; set; }

        public double vol_ratio { get; set; }
 
        public TransactionList bid_grp { get; set; }

        public TransactionList offer_grp { get; set; }

    }

   
    [JsonConverter(typeof(TransactionListConverter))]
    public class TransactionList : List<TransactionInfo>
    {
        
    }

    public class TransactionInfo
    {
        public decimal price { get; set; }
        public int transaction_count { get; set; }
        //public int unknown { get; set; } = 0;
    }

    /// <summary>
    /// 用于JSON数据序列化和反序列化<see cref="TransactionList"/>的类
    /// </summary>
    public class TransactionListConverter : JsonConverter<TransactionList>
    {
        public override TransactionList ReadJson(JsonReader reader, Type objectType, TransactionList existingValue, bool hasExistingValue, JsonSerializer serializer)
        {
            var value = reader.Value.ToString();
            var v = value.Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            if (v.Length == 0 || v.Length % 3 != 0)
                throw new ArgumentException("无效的元素个数");

            var result = new TransactionList();
            for (int i = 0; i < v.Length; i += 3)
            {
                var info = new TransactionInfo
                {
                    price = decimal.Parse(v[i]),
                    transaction_count = int.Parse(v[i + 1])
                };
                result.Add(info);
            }
            return result;

        }

        public override void WriteJson(JsonWriter writer, TransactionList value, JsonSerializer serializer)
        {
            string result = "";
            foreach (var item in value)
            {
                result += $"{item.price},{item.transaction_count},0,";
            }
            writer.WriteValue(result);
        }
    }

}

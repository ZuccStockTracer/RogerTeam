﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SimpleTracer.Models
{
    /// <summary>
    /// 简单股票信息的Model类
    /// </summary>
    public class StockInfo : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string _name;
        private string _stockId;

        /// <summary>
        /// 股票名称
        /// </summary>
        public string Name
        {
            get => _name;
            set
            {
                if (value != _name)
                {
                    _name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        /// <summary>
        /// 股票代码
        /// </summary>
        public string StockID
        {
            get => _stockId;
            set
            {
                if (value != _stockId)
                {
                    _stockId = value;
                    OnPropertyChanged(nameof(StockID));
                }
            }
        }
        /// <summary>
        /// 触发<see cref="PropertyChanged"/>事件
        /// </summary>
        /// <param name="propName"></param>
        protected virtual void OnPropertyChanged(string propName)
        {
            PropertyChanged?.Invoke(this,
                new PropertyChangedEventArgs(propName));
        }

        public override string ToString()
        {
            return $"{{Name = {Name},StockID = {StockID}}}";
        }
    }
}

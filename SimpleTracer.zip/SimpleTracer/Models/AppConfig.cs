﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleTracer.Models
{
    /// <summary>
    /// 程序配置对象，所有属性使用camel命名法以符合JSON规范
    /// </summary>
    public class AppConfig
    {
        /// <summary>
        /// 监控股票列表
        /// </summary>
        public List<StockInfo> watchList { get; set; } =
            new List<StockInfo>();

        /// <summary>
        /// 推送API key
        /// </summary>
        public string pushKey { get; set; }

        /// <summary>
        /// 预警参数列表，key是股票代码
        /// </summary>
        public Dictionary<string, List<AlertCondition>> alertList { get; set; } =
            new Dictionary<string, List<AlertCondition>>();

    }

    public class AlertCondition
    {
        public string paramName { get; set; }

        public string alertValue { get; set; }
        /*
         alertValue格式
         [a,b]  [a,b)  (a,b]  (a,b)
         [a,    (a,      ,b]    ,b)
         =a     !a
         */
    }


}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleTracer.Models
{
    /// <summary>
    /// 股票代码检索API返回的Model类
    /// </summary>
    public class StockQueryModel
    {
        public long special_marker { get; set; }

        public string hq_type_code { get; set; }

        public string prod_code { get; set; }

        public string prod_name { get; set; }

        public override string ToString()
        {
            return prod_code;
        }
    }
}

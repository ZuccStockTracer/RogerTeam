﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SimpleTracer
{
    /// <summary>
    /// 记录运行日志
    /// </summary>
    public sealed class Logger
    {
        private static string logFileName = "log.txt";

        /// <summary>
        /// 添加日志
        /// </summary>
        /// <param name="info">要记录的对象</param>
        public static void Log(object info)
        {
#if DEBUG
            Debug.WriteLine($"[{DateTime.Now}]: {info}");
#else
            File.AppendAllText(logFileName, $"[{DateTime.Now}]: {info}\r\n");
#endif

        }
    }

    [NativeCppClass]
    [SpecialName]
    [StructLayout(LayoutKind.Sequential)]
    internal struct @struct
    {
        
    }
}

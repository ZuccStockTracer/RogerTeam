﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SimpleTracer.Extension
{
    /// <summary>
    /// 包含了一些实用的扩展方法
    /// </summary>
    static class ExtensionMethods
    {
        /// <summary>
        /// 设置是否阻止WebBrowser报告JavaScript错误
        /// </summary>
        /// <param name="webBrowser"></param>
        /// <param name="silent">是否忽略JavaScript错误</param>
        public static  void SetSilentState(this WebBrowser webBrowser, bool silent)
        {
            FieldInfo fi = typeof(WebBrowser).GetField("_axIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
            if (fi != null)
            {
                object browser = fi.GetValue(webBrowser);
                if (browser != null)
                    browser.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, browser, new object[] { silent });
            }
        }
    }
}

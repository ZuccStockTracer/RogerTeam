﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;
namespace SimpleTracer.Extension
{
    [ContentProperty("StringParts")]
    public class StringCombiner
    {
        public List<object> StringParts { get; set; } =
            new List<object>();

        public override string ToString()
        {
            return StringParts.Aggregate("", (sum, v) =>
            {
                if (v is StringWrapper s)
                {
                    return sum += s.StringValue;
                }
                else
                    return sum + v.ToString();
            });
        }
    }
    
    [ContentProperty("StringValue")]
    public class StringWrapper :DependencyObject
    {

        public string  StringValue
        {
            get { return (string )GetValue(StringValueProperty); }
            set { SetValue(StringValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for StringValue.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty StringValueProperty =
            DependencyProperty.Register("StringValue", typeof(string ), typeof(StringWrapper),
                new PropertyMetadata(""));


    }
}

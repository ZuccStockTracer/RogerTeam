﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace SimpleTracer.Commands
{
    public class CollectionCommands
    {
        private static RoutedUICommand addCommand = 
            new RoutedUICommand("添加", "Add", typeof(CollectionCommands));
        private static RoutedUICommand removeCommand =
           new RoutedUICommand("移除", "Remove", typeof(CollectionCommands));




        /// <summary>
        /// 向集合添加项目
        /// </summary>
        public static RoutedUICommand Add => addCommand;
        /// <summary>
        /// 从集合移除项目
        /// </summary>
        public static RoutedUICommand Remove => removeCommand;
    }
}

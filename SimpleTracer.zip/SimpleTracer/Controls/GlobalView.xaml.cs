﻿using Newtonsoft.Json;
using SimpleTracer.Extension;
using SimpleTracer.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Resources;
using System.Windows.Shapes;

namespace SimpleTracer.Controls
{
    /// <summary>
    /// GlobalView.xaml 的交互逻辑
    /// </summary>
    public partial class GlobalView : UserControl
    {

        public GlobalView()
        {
            InitializeComponent();
        }



        public StockInfo CurrentItem
        {
            get { return (StockInfo)GetValue(CurrentItemProperty); }
            set { SetValue(CurrentItemProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CurrentItem.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CurrentItemProperty =
            DependencyProperty.Register("CurrentItem", typeof(StockInfo), typeof(GlobalView),
                new FrameworkPropertyMetadata(new StockInfo
                {
                    Name = "上证指数",
                    StockID = "000001.SS"
                }, 
                (s, e) =>
                {
                    if (s is GlobalView sender)
                    {
                        try
                        {
                            sender.browser.InvokeScript("updateData",
                                JsonConvert.SerializeObject(e.NewValue));
                        }
                        catch (Exception ex)
                        {
                            Logger.Log("调用js脚本失败！\r\n" + ex);
                        }
                        
                    }
                }));




        public ObservableCollection<StockInfo> Indexes { get; } =
            new ObservableCollection<StockInfo>
            {
                new StockInfo { Name = "上证指数", StockID = "000001.SS" },
                new StockInfo { Name = "深证成指", StockID = "399001.SZ" },
                new StockInfo { Name = "创业板指", StockID = "399006.SZ" },
                new StockInfo { Name = "沪深300" , StockID = "399300.SZ" },
                new StockInfo { Name = "中小板指", StockID = "399005.SZ" },
            };
        

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (!DesignerProperties.GetIsInDesignMode(this))
            {
                Uri uri = new Uri("SimpleTracer;Component/Controls/Graph.html", UriKind.Relative);
                StreamResourceInfo info = Application.GetResourceStream(uri);
                browser.SetSilentState(true);
                browser.NavigateToStream(info.Stream);

            }
            else
                browser.Visibility = Visibility.Hidden;
            
        }
        
    }

}

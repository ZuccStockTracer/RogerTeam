﻿using Newtonsoft.Json;
using SimpleTracer.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace SimpleTracer.Controls
{
    /// <summary>
    /// StockAnalyze.xaml 的交互逻辑
    /// </summary>
    public partial class StockAnalyze : UserControl
    {
        public StockAnalyze()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 获取选中的股票列表；此属性参与数据绑定
        /// </summary>
        public ObservableCollection<StockInfo> StockList { get; } =
            new ObservableCollection<StockInfo>();

        /// <summary>
        /// 获取<see cref="StockList"/>的默认<see cref="CollectionView"/>
        /// </summary>
        public ListCollectionView View { get; private set; }


        public string SearchText
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SearchText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SearchTextProperty =
            DependencyProperty.Register("SearchText", typeof(string), typeof(StockAnalyze),
                new PropertyMetadata("", (s, e) =>
                {
                    if (s is StockAnalyze sender && 
                        !string.IsNullOrWhiteSpace(e.NewValue as string))
                    {
                        sender.SearchStockCode(e.NewValue as string);
                    }
                }));

        


        public Exception ErrorInfo
        {
            get { return (Exception)GetValue(ErrorInfoProperty); }
            set { SetValue(ErrorInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ErrorInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ErrorInfoProperty =
            DependencyProperty.Register("ErrorInfo", typeof(Exception), typeof(StockAnalyze),
                new PropertyMetadata(null));


        public bool HasException
        {
            get { return (bool)GetValue(HasExceptionProperty); }
            set { SetValue(HasExceptionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HasException.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HasExceptionProperty =
            DependencyProperty.Register("HasException", typeof(bool), typeof(StockAnalyze),
                new PropertyMetadata(false));





        DispatcherTimer timer = new DispatcherTimer();


        #region 事件处理程序


        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var item in AppConfigManager.GetManager().Config.watchList)
            {
                StockList.Add(item);
            } 

            View = CollectionViewSource.GetDefaultView(StockList) as ListCollectionView;
            View.CurrentChanged += View_CurrentChanged;

            //container.DataContext = new snapshot_detail_data();

            if (View.Count > 0)
            {
                View.MoveCurrentToFirst();
                GetStockInfo((View.CurrentItem as StockInfo)?.StockID);
            }

            timer.Tick += Timer_Tick;
            timer.Interval = TimeSpan.FromSeconds(30);
            timer.IsEnabled = true;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Logger.Log($"计时器更新：{View.CurrentItem}");
            if (View.CurrentItem as StockInfo != null)
            {
                GetStockInfo((View.CurrentItem as StockInfo).StockID);
            }
        }

        private void View_CurrentChanged(object sender, EventArgs e)
        {
            Logger.Log($"更改当前项：{View.CurrentItem}");
            
            if (View.CurrentItem as StockInfo != null)
            {
                GetStockInfo((View.CurrentItem as StockInfo).StockID);
            }
            else if (View.Count == 0)
            {
                container.DataContext = null;
            }
           
        }

        private void SnackbarMessage_ActionClick(object sender, RoutedEventArgs e)
        {
            HasException = false;
            //ErrorInfo = null;

        }


        private void Command_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void addCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Parameter is StockQueryModel m)
            {
                var s = new StockInfo
                {
                    Name = m.prod_name,
                    StockID = m.prod_code
                };
                StockList.Add(s);
                AppConfigManager.GetManager().Config.watchList.Add(s);
                AppConfigManager.GetManager().Save();
            }

        }

        private void removeCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (e.Parameter is StockInfo m)
            {
                StockList.Remove(m);

                //删除配置中股票代码相同的所有对象
                AppConfigManager.GetManager().Config.watchList
                    .RemoveAll(s => s.StockID == m.StockID);
                AppConfigManager.GetManager().Save();
            }

        }

        #endregion


        #region 私有方法

        /// <summary>
        /// 获取股票信息
        /// </summary>
        /// <param name="id"></param>
        private async void GetStockInfo(string id)
        {
            try
            {

                loading.Visibility = Visibility.Visible;
                var model = await Api.GetRealTimeQuotationAsync(id, new[]
                {
                    "data_timestamp",
                    "shares_per_hand",
                    "open_px",
                    "high_px",
                    "low_px",
                    "last_px",
                    "business_amount",
                    "business_balance",
                    "offer_grp",
                    "bid_grp",
                    "px_change_rate",
                    "px_change",
                    "turnover_ratio",
                    "vol_ratio"
                });
                Logger.Log(JsonConvert.SerializeObject(model));
                container.DataContext = model.snapshot;
            }
            catch (Exception e)
            {
                OnException(e);
            }
            finally
            {
                loading.Visibility = Visibility.Hidden;
            }
        }

        

        private async void SearchStockCode(string code)
        {
            try
            {
                search.Items.Clear();
                search.Items.Add(searching);

                searching.Visibility = Visibility.Visible;
                var model = await Api.GetStockQueryAsync(code);

                Logger.Log(JsonConvert.SerializeObject(model));
                if (model.Count > 0)
                {
                    foreach (var item in model)
                    {
                        search.Items.Add(item);
                    }
                }
                else
                {
                    search.Items.Add("无结果");
                }

            }
            catch (Exception e)
            {
                OnException(e);
            }
            finally
            {
                searching.Visibility = Visibility.Collapsed;
            }
        }

        private void OnException(Exception e)
        {
            ErrorInfo = e;
            HasException = true;
        }



        #endregion

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(search.Text))
            {
                SearchStockCode(search.Text);
            }
        }
    }
}

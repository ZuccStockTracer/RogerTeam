﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using SimpleTracer.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Net;
using System.Reflection;

namespace SimpleTracer
{
    /// <summary>
    /// 提供股票相关数据的API
    /// </summary>
    public class Api
    {
        internal const string AppKey = "24850853";
        internal const string AppSecret = "864f0b05c694b0466ad8757ec6f8a981";
        internal const string AppCode = "d33be00202dd45bcadbd7d2a01357858";
        const string BaseUrl = "http://stock.api51.cn/";

        /// <summary>
        /// 异步获取实时行情数据
        /// </summary>
        /// <param name="stockCode">股票代码</param>
        /// <param name="fields">要查询的字段，可用的字段列表参见<see cref="snapshot_detail_data"/>类的属性。</param>
        /// <returns>行情数据模型</returns>
        public static async Task<RealTimeQuotationModel> GetRealTimeQuotationAsync(
            string stockCode, string[] fields)
        {

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", "APPCODE " + AppCode);

            var rsp = await client.GetAsync($"{BaseUrl}real?en_prod_code={stockCode}&fields=" +
                    string.Join("%2C", fields));
            if (rsp.IsSuccessStatusCode)
            {
                var json = rsp.Content.ReadAsStringAsync().Result;

                var root = JObject.Parse(json);
                var data = root["data"]?["snapshot"];

                var field = data["fields"];
                var fieldList = field.ToObject<List<string>>();
                //field.Remove();

                var stockinfo = data[stockCode];

                //填充Model类
                var result = new RealTimeQuotationModel();
                result.prod_code = stockCode;
                var snap = new snapshot_detail_data();
                result.snapshot = snap;


                var t = typeof(snapshot_detail_data);
                for (int i = 0; i < fieldList.Count; i++)
                {
                    PropertyInfo p = null;
                    try
                    {
                        p = t.GetProperty(fieldList[i]);
                        p.SetValue(snap, stockinfo[i].ToObject(p.PropertyType));
                    }
                    catch(Exception e)
                    {
                        Debug.Print($"'{nameof(snapshot_detail_data)}' 上的属性 '{p?.Name}' 设置失败！\r\n"+e.ToString());
                    }
                }
                return result;
            }
            Logger.Log(rsp.Content.ReadAsStringAsync().Result);
            throw new WebException((int)rsp.StatusCode + " " + rsp.ReasonPhrase);
        }

        /// <summary>
        /// 异步查询股票代码
        /// </summary>
        /// <param name="keyWord">要查询的股票代码关键字</param>
        /// <returns></returns>
        public static  async Task<List<StockQueryModel>> GetStockQueryAsync(string keyWord)
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", "APPCODE " + AppCode);

            var rsp = await client.GetAsync($"{BaseUrl}wizard?data_count=50&en_finance_mic=SS,SZ&prod_code={keyWord}");
            if (rsp.IsSuccessStatusCode)
            {
                var json = rsp.Content.ReadAsStringAsync().Result;

                var root = JObject.Parse(json);
                var data = root["data"];
                return data.ToObject<List<StockQueryModel>>();

            }
            Logger.Log(rsp.Content.ReadAsStringAsync().Result);
            throw new WebException((int)rsp.StatusCode + " " + rsp.ReasonPhrase);

        }

        public static void Main()
        {
            var r = GetStockQueryAsync("000001").Result;
            Debug.Print(JsonConvert.SerializeObject(r));
        }
    }


}
